from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('select/student/', views.redirect_to_students, name='select_student'),
    path('select/teacher/', views.redirect_to_teachers, name='select_teacher'),
    path('std/', include('students.urls')),
    path('', include('accounts.urls')),  # This handles /login etc.
]
